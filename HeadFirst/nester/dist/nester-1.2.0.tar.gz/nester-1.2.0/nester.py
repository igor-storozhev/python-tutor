"""This is the "nester.py" module, and it provides one function called
print_lol() wich prints list that may or may not include nested lists.
A second argument called "level" is used to insert tab-stops when a nested
list encountered"""
def print_lol(the_list, level=0):
	"""This function takes a positional arguments called "the list", which is an
	Python list (of, possibly, nested lists). Each data item in the provided list
	is (recursively) printed to screen on its own line"""
	for each_item in the_list :
		if isinstance(each_item,list) :
			print_lol(each_item, level+1)
		else:
			for num in range(level):
				print("\t",end='')
			print(each_item)
